<?php
//SetCookie('regId', "", 0, '/');
$fp = fopen("./regId.php", w);
fputs($fp, '');
fclose($fp);

?>